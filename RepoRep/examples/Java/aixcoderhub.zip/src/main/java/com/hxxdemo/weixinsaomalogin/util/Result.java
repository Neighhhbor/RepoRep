package com.hxxdemo.weixinsaomalogin.util;

public class Result <T>{
	
	public T value;
	public String msg;

}
