package com.hxxdemo.message.service.impl;

import java.util.Map;

public interface MessageService {

	int insert(Map<String, Object> params) ;
}
