package com.hxxdemo.cooperation.service;

import java.util.Map;

public interface CooperationService {

	void insertCooperation(Map<String, Object> params);
}
