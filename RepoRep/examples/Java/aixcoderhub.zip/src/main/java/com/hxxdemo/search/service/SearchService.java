package com.hxxdemo.search.service;

import java.util.Map;

public interface SearchService {

	void createSearchTimes(Map<String, Object> params);
}
