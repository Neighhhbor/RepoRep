package com.hxxdemo.weixinsaomalogin.util;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * 菜单工具类
 * @author Administrator
 *
 */
public class MenuUtil {
	
	private static Logger log = LoggerFactory.getLogger(MenuUtil.class);
	

	
	
	
	
	
	
}
