package com.hxxdemo.baidu.service;

public interface BaiduService {

	int getSwitch(String source);
}
