package com.hxxdemo.weixinsaomalogin.resp;

public class Image {

	//素材id
	private String MediaId;

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}
}
