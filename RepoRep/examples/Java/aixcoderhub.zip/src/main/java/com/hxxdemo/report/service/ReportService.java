package com.hxxdemo.report.service;

import java.util.Map;

public interface ReportService {
	
	void insertReportCity(Map<String, Object> params);
}
