package com.hxxdemo.weixinsaomalogin.util;

public enum EnumEventType {
	subscribe, unsubscribe, LOCATION, CLICK, VIEW;
}
