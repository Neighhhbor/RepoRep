package com.hxxdemo.weixinsaomalogin.entity;

import java.util.List;
import java.util.Map;

public class Menu {

	private List<Map<String,Object>> button;

	public List<Map<String,Object>> getButton() {
		return button;
	}

	public void setButton(List<Map<String,Object>> button) {
		this.button = button;
	}
}
