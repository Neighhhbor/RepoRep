package com.hxxdemo.index.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import sun.misc.BASE64Encoder;

public class Md5Util {

	  /**利用MD5进行加密
     * @param str  待加密的字符串
     * @return  加密后的字符串
     * @throws NoSuchAlgorithmException  没有这种产生消息摘要的算法
     * @throws UnsupportedEncodingException  
     */
    public static String md5(String str) throws NoSuchAlgorithmException, UnsupportedEncodingException{
        //确定计算方法
        MessageDigest md5=MessageDigest.getInstance("MD5");
        BASE64Encoder base64en = new BASE64Encoder();
        //加密后的字符串
        String newstr=base64en.encode(md5.digest(str.getBytes("utf-8")));
        if(newstr.contains("+")) {
        	newstr = newstr.replaceAll("+", (int)(Math.random()*(9-1+1)+1)+"");
        }
        if(newstr.contains("-")) {
        	newstr = newstr.replaceAll("-", (int)(Math.random()*(9-1+1)+1)+"");
        }
        return newstr;
    }
}
