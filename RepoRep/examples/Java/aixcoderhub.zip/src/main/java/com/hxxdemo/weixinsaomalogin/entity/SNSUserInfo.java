package com.hxxdemo.weixinsaomalogin.entity;

import java.util.List;

/**
 * 通过网页授权获取用户信息
 * @author Administrator
 *
 */
public class SNSUserInfo {
	//自增长id
	private Long id;
	//用户标识
	private String openId;
	
	//用户昵称
	private String nickname;
	
	//性别(1 是男性 2 是女性  0 是未知)
	private int sex;
	
	//国家
	private String country;
	
	//省份
	private String province;
	
	//城市
	private String city;
	
	//头像
	private String headImgUrl;
	
	//用户特权信息
	private List<String> privilegeList;
	//唯一id
	private String unionid;
	//备注
	private String remark;
	//创建时间
	private String createtime;
	//修改时间
	private String edittime;
	//是否关注
    private int isfollow;
    //关注时间
    private String subscribetime;
    
	public String getSubscribetime() {
		return subscribetime;
	}

	public void setSubscribetime(String subscribetime) {
		this.subscribetime = subscribetime;
	}

	public int getIsfollow() {
		return isfollow;
	}

	public void setIsfollow(int isfollow) {
		this.isfollow = isfollow;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public String getEdittime() {
		return edittime;
	}

	public void setEdittime(String edittime) {
		this.edittime = edittime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getUnionid() {
		return unionid;
	}

	public void setUnionid(String unionid) {
		this.unionid = unionid;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHeadImgUrl() {
		return headImgUrl;
	}

	public void setHeadImgUrl(String headImgUrl) {
		this.headImgUrl = headImgUrl;
	}

	public List<String> getPrivilegeList() {
		return privilegeList;
	}

	public void setPrivilegeList(List<String> privilegeList) {
		this.privilegeList = privilegeList;
	}
	
	
	

}
