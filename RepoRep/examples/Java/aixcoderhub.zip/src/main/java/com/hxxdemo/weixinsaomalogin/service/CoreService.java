package com.hxxdemo.weixinsaomalogin.service;

import javax.servlet.http.HttpServletRequest;

public interface CoreService {

	String processRequest(HttpServletRequest request);
}
