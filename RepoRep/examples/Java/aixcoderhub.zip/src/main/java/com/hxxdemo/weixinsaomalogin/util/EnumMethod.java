package com.hxxdemo.weixinsaomalogin.util;

public enum EnumMethod {
	GET,POST;
}
